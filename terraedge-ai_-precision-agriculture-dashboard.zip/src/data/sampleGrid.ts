import { FarmGrid } from "../types";

export const SAMPLE_FARM_GRID: FarmGrid = {
  farmId: "TERRA-RURAL-001",
  zones: [
    {
      id: "Zone 1",
      location: "North-West Quadrant",
      cropType: "Wheat",
      timestamp: "2026-02-24T03:41:56Z",
      soil: {
        moisture: 35,
        nitrogen: 52,
        phosphorus: 28,
        potassium: 195,
        ph: 6.8,
        temperature: 21
      },
      satellite: {
        ndvi: 0.72,
        evi: 0.45,
        canopyCover: 82
      },
      weather: Array.from({ length: 7 }).map((_, i) => ({
        date: new Date(Date.now() + i * 86400000).toISOString().split('T')[0],
        tempMax: 22 + Math.random() * 5,
        tempMin: 12 + Math.random() * 5,
        precipitation: Math.random() < 0.2 ? Math.random() * 10 : 0,
        humidity: 50 + Math.random() * 20,
        windSpeed: 10 + Math.random() * 10
      }))
    },
    {
      id: "Zone 2",
      location: "North-East Quadrant",
      cropType: "Soybeans",
      timestamp: "2026-02-24T03:41:56Z",
      soil: {
        moisture: 42,
        nitrogen: 38,
        phosphorus: 35,
        potassium: 210,
        ph: 6.2,
        temperature: 23
      },
      satellite: {
        ndvi: 0.65,
        evi: 0.38,
        canopyCover: 68
      },
      weather: Array.from({ length: 7 }).map((_, i) => ({
        date: new Date(Date.now() + i * 86400000).toISOString().split('T')[0],
        tempMax: 24 + Math.random() * 5,
        tempMin: 14 + Math.random() * 5,
        precipitation: Math.random() < 0.3 ? Math.random() * 15 : 0,
        humidity: 55 + Math.random() * 20,
        windSpeed: 8 + Math.random() * 10
      }))
    },
    {
      id: "Zone 3",
      location: "South-West Quadrant",
      cropType: "Maize",
      timestamp: "2026-02-24T03:41:56Z",
      anomaly: "Potential Pest Outbreak / Severe Nitrogen Deficiency Detected",
      soil: {
        moisture: 28,
        nitrogen: 12, // Anomaly: Very low nitrogen
        phosphorus: 25,
        potassium: 160,
        ph: 5.8,
        temperature: 25
      },
      satellite: {
        ndvi: 0.42, // Anomaly: Low NDVI for Maize at this stage
        evi: 0.25,
        canopyCover: 45
      },
      weather: Array.from({ length: 7 }).map((_, i) => ({
        date: new Date(Date.now() + i * 86400000).toISOString().split('T')[0],
        tempMax: 27 + Math.random() * 5,
        tempMin: 17 + Math.random() * 5,
        precipitation: Math.random() < 0.1 ? Math.random() * 5 : 0,
        humidity: 40 + Math.random() * 20,
        windSpeed: 12 + Math.random() * 10
      }))
    },
    {
      id: "Zone 4",
      location: "South-East Quadrant",
      cropType: "Barley",
      timestamp: "2026-02-24T03:41:56Z",
      soil: {
        moisture: 38,
        nitrogen: 48,
        phosphorus: 32,
        potassium: 185,
        ph: 6.5,
        temperature: 20
      },
      satellite: {
        ndvi: 0.78,
        evi: 0.48,
        canopyCover: 88
      },
      weather: Array.from({ length: 7 }).map((_, i) => ({
        date: new Date(Date.now() + i * 86400000).toISOString().split('T')[0],
        tempMax: 20 + Math.random() * 5,
        tempMin: 10 + Math.random() * 5,
        precipitation: Math.random() < 0.4 ? Math.random() * 20 : 0,
        humidity: 60 + Math.random() * 20,
        windSpeed: 15 + Math.random() * 10
      }))
    }
  ]
};
