export interface SoilData {
  moisture: number; // percentage
  nitrogen: number; // mg/kg
  phosphorus: number; // mg/kg
  potassium: number; // mg/kg
  ph: number;
  temperature: number; // celsius
}

export interface SatelliteData {
  ndvi: number; // Normalized Difference Vegetation Index (0-1)
  evi: number; // Enhanced Vegetation Index (0-1)
  canopyCover: number; // percentage
}

export interface WeatherForecast {
  date: string;
  tempMax: number;
  tempMin: number;
  precipitation: number; // mm
  humidity: number;
  windSpeed: number;
}

export interface FarmData {
  id: string;
  timestamp: string;
  soil: SoilData;
  satellite: SatelliteData;
  weather: WeatherForecast[];
  cropType: string;
  location: string;
  anomaly?: string;
}

export interface FarmGrid {
  farmId: string;
  zones: FarmData[];
}

export interface OptimizationResult {
  yieldProjection: number; // 0-100 score
  waterEfficiency: number; // 0-100 score
  sustainabilityScore: number; // 0-100 score
  recommendations: {
    action: string;
    priority: 'High' | 'Medium' | 'Low';
    impact: string;
  }[];
  summary: string;
}

export interface GlobalAnalysisResult {
  cropRecommendations: {
    zoneId: string;
    recommendedCrop: string;
    reasoning: string;
  }[];
  irrigationSchedule: {
    zoneId: string;
    litersPerDay: number;
    timing: string;
    logic: string;
  }[];
  sustainabilityScorecard: {
    score: number;
    metrics: string[];
    grade: string;
  };
  anomalyReport: {
    zoneId: string;
    finding: string;
    intervention: string;
  }[];
}
