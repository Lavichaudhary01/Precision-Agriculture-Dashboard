import { GoogleGenAI, Type } from "@google/genai";
import { FarmData, OptimizationResult, FarmGrid, GlobalAnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function getGlobalFarmAnalysis(grid: FarmGrid): Promise<GlobalAnalysisResult> {
  const prompt = `
    Analyze the following rural farm grid data for 4 distinct zones. 
    Perform multi-objective optimization (Yield, Water, Sustainability).
    
    Grid Data:
    ${JSON.stringify(grid, null, 2)}

    Output the following deliverables:
    1. Crop Recommendation Engine: Specific crops for each zone based on 7-day forecast and soil data.
    2. Irrigation Optimization Module: Precise watering schedule (in liters) for each zone.
    3. Sustainability Impact Scorecard: Grade (1-100) citing specific data points.
    4. Anomaly Detection: Flag any spatial anomalies and recommend immediate, low-cost interventions.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          cropRecommendations: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                zoneId: { type: Type.STRING },
                recommendedCrop: { type: Type.STRING },
                reasoning: { type: Type.STRING }
              },
              required: ["zoneId", "recommendedCrop", "reasoning"]
            }
          },
          irrigationSchedule: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                zoneId: { type: Type.STRING },
                litersPerDay: { type: Type.NUMBER },
                timing: { type: Type.STRING },
                logic: { type: Type.STRING }
              },
              required: ["zoneId", "litersPerDay", "timing", "logic"]
            }
          },
          sustainabilityScorecard: {
            type: Type.OBJECT,
            properties: {
              score: { type: Type.NUMBER },
              metrics: { type: Type.ARRAY, items: { type: Type.STRING } },
              grade: { type: Type.STRING }
            },
            required: ["score", "metrics", "grade"]
          },
          anomalyReport: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                zoneId: { type: Type.STRING },
                finding: { type: Type.STRING },
                intervention: { type: Type.STRING }
              },
              required: ["zoneId", "finding", "intervention"]
            }
          }
        },
        required: ["cropRecommendations", "irrigationSchedule", "sustainabilityScorecard", "anomalyReport"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
}

export async function getClimateInsights(data: FarmData): Promise<OptimizationResult> {
  const prompt = `
    As the core reasoning engine for an AI-Driven Climate-Resilient Precision Agriculture System, 
    analyze the following farm data and provide multi-objective optimization insights.
    
    Goals:
    1. Maximize crop yield.
    2. Minimize water usage.
    3. Maximize environmental sustainability.

    Farm Data:
    ${JSON.stringify(data, null, 2)}

    Provide practical, farmer-friendly insights.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          yieldProjection: { type: Type.NUMBER, description: "Score from 0-100" },
          waterEfficiency: { type: Type.NUMBER, description: "Score from 0-100" },
          sustainabilityScore: { type: Type.NUMBER, description: "Score from 0-100" },
          recommendations: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                action: { type: Type.STRING },
                priority: { type: Type.STRING, enum: ["High", "Medium", "Low"] },
                impact: { type: Type.STRING }
              },
              required: ["action", "priority", "impact"]
            }
          },
          summary: { type: Type.STRING }
        },
        required: ["yieldProjection", "waterEfficiency", "sustainabilityScore", "recommendations", "summary"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
}
