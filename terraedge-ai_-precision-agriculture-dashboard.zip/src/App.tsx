import React, { useState, useEffect } from 'react';
import { 
  Sprout, 
  Droplets, 
  Leaf, 
  CloudRain, 
  Thermometer, 
  Wind, 
  Activity,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  ChevronRight,
  BarChart3,
  Map as MapIcon,
  Layers,
  Globe,
  ClipboardList,
  Zap
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { FarmData, OptimizationResult, GlobalAnalysisResult } from './types';
import { getClimateInsights, getGlobalFarmAnalysis } from './services/geminiService';
import { cn } from './lib/utils';
import { SAMPLE_FARM_GRID } from './data/sampleGrid';

export default function App() {
  const [selectedZoneId, setSelectedZoneId] = useState<string>(SAMPLE_FARM_GRID.zones[0].id);
  const [data, setData] = useState<FarmData>(SAMPLE_FARM_GRID.zones[0]);
  const [insights, setInsights] = useState<OptimizationResult | null>(null);
  const [globalAnalysis, setGlobalAnalysis] = useState<GlobalAnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [globalLoading, setGlobalLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'soil' | 'satellite' | 'weather' | 'global'>('overview');

  const fetchInsights = async (zoneData: FarmData) => {
    setLoading(true);
    try {
      const result = await getClimateInsights(zoneData);
      setInsights(result);
    } catch (error) {
      console.error("Failed to fetch insights:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchGlobalAnalysis = async () => {
    setGlobalLoading(true);
    try {
      const result = await getGlobalFarmAnalysis(SAMPLE_FARM_GRID);
      setGlobalAnalysis(result);
    } catch (error) {
      console.error("Failed to fetch global analysis:", error);
    } finally {
      setGlobalLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'global') {
      if (!globalAnalysis) fetchGlobalAnalysis();
      return;
    }
    const zone = SAMPLE_FARM_GRID.zones.find(z => z.id === selectedZoneId) || SAMPLE_FARM_GRID.zones[0];
    setData(zone);
    fetchInsights(zone);
  }, [selectedZoneId, activeTab]);

  const StatCard = ({ title, value, unit, icon: Icon, trend, color }: any) => (
    <div className="bg-white p-4 rounded-xl border border-zinc-200 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-2">
        <div className={cn("p-2 rounded-lg", color)}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        {trend !== undefined && (
          <span className={cn("text-xs font-medium px-2 py-1 rounded-full", 
            trend > 0 ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600")}>
            {trend > 0 ? '+' : ''}{trend}%
          </span>
        )}
      </div>
      <div>
        <p className="text-sm text-zinc-500 font-medium">{title}</p>
        <div className="flex items-baseline gap-1">
          <h3 className="text-2xl font-bold text-zinc-900">{value}</h3>
          <span className="text-sm text-zinc-400 font-normal">{unit}</span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-zinc-900 font-sans selection:bg-emerald-100">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-zinc-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-200">
              <Sprout className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">TerraEdge AI</h1>
              <p className="text-xs text-zinc-500 font-medium uppercase tracking-wider">Precision Agriculture Engine</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="flex bg-zinc-100 p-1 rounded-xl border border-zinc-200 w-full md:w-auto overflow-x-auto">
              {['overview', 'global'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab as any)}
                  className={cn(
                    "px-4 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap",
                    (activeTab === tab || (tab === 'overview' && activeTab !== 'global'))
                      ? "bg-white text-emerald-600 shadow-sm" 
                      : "text-zinc-500 hover:text-zinc-700"
                  )}
                >
                  {tab === 'overview' ? 'Zone View' : 'Global Analysis'}
                </button>
              ))}
            </div>

            {activeTab !== 'global' && (
              <div className="flex bg-zinc-100 p-1 rounded-xl border border-zinc-200">
                {SAMPLE_FARM_GRID.zones.map((zone) => (
                  <button
                    key={zone.id}
                    onClick={() => setSelectedZoneId(zone.id)}
                    className={cn(
                      "px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all",
                      selectedZoneId === zone.id 
                        ? "bg-white text-emerald-600 shadow-sm" 
                        : "text-zinc-500 hover:text-zinc-700"
                    )}
                  >
                    {zone.id}
                  </button>
                ))}
              </div>
            )}

            <button 
              onClick={() => activeTab === 'global' ? fetchGlobalAnalysis() : fetchInsights(data)}
              disabled={loading || globalLoading}
              className="hidden md:flex items-center gap-2 bg-zinc-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-zinc-800 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={cn("w-4 h-4", (loading || globalLoading) && "animate-spin")} />
              {(loading || globalLoading) ? 'Optimizing...' : 'Re-Run'}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <AnimatePresence mode="wait">
          {activeTab === 'global' ? (
            <motion.div 
              key="global-view"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              {globalLoading ? (
                <div className="flex flex-col items-center justify-center py-32 space-y-4">
                  <div className="w-16 h-16 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin" />
                  <p className="text-zinc-500 font-medium">Synthesizing full grid optimization strategy...</p>
                </div>
              ) : globalAnalysis && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  {/* Left: Recommendations & Irrigation */}
                  <div className="lg:col-span-8 space-y-8">
                    <section className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden">
                      <div className="bg-emerald-600 px-6 py-4 flex items-center gap-3">
                        <ClipboardList className="text-white w-5 h-5" />
                        <h2 className="text-white font-bold">Crop Recommendation Engine</h2>
                      </div>
                      <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                        {globalAnalysis.cropRecommendations.map((rec, i) => (
                          <div key={i} className="p-4 rounded-xl bg-zinc-50 border border-zinc-100">
                            <div className="flex items-center gap-2 mb-2">
                              <span className="text-[10px] font-black bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded uppercase">{rec.zoneId}</span>
                              <h3 className="font-bold text-zinc-900">{rec.recommendedCrop}</h3>
                            </div>
                            <p className="text-xs text-zinc-500 leading-relaxed">{rec.reasoning}</p>
                          </div>
                        ))}
                      </div>
                    </section>

                    <section className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden">
                      <div className="bg-blue-600 px-6 py-4 flex items-center gap-3">
                        <Droplets className="text-white w-5 h-5" />
                        <h2 className="text-white font-bold">Irrigation Optimization Module</h2>
                      </div>
                      <div className="p-6">
                        <div className="overflow-x-auto">
                          <table className="w-full text-left">
                            <thead>
                              <tr className="text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">
                                <th className="pb-4">Zone</th>
                                <th className="pb-4">Daily Target</th>
                                <th className="pb-4">Optimal Timing</th>
                                <th className="pb-4">Logic</th>
                              </tr>
                            </thead>
                            <tbody className="text-sm">
                              {globalAnalysis.irrigationSchedule.map((item, i) => (
                                <tr key={i} className="border-b border-zinc-50 last:border-0">
                                  <td className="py-4 font-bold text-zinc-900">{item.zoneId}</td>
                                  <td className="py-4 text-blue-600 font-mono font-bold">{item.litersPerDay}L</td>
                                  <td className="py-4 text-zinc-600">{item.timing}</td>
                                  <td className="py-4 text-xs text-zinc-400 max-w-xs">{item.logic}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </section>
                  </div>

                  {/* Right: Scorecard & Anomalies */}
                  <div className="lg:col-span-4 space-y-8">
                    <section className="bg-zinc-900 text-white rounded-2xl p-6 shadow-xl">
                      <div className="flex items-center gap-3 mb-6">
                        <Globe className="w-6 h-6 text-emerald-400" />
                        <h2 className="text-lg font-bold">Sustainability Scorecard</h2>
                      </div>
                      <div className="flex items-center justify-center mb-8">
                        <div className="relative w-32 h-32 flex items-center justify-center">
                          <svg className="w-full h-full transform -rotate-90">
                            <circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-zinc-800" />
                            <motion.circle 
                              cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="8" fill="transparent" 
                              strokeDasharray={364}
                              initial={{ strokeDashoffset: 364 }}
                              animate={{ strokeDashoffset: 364 - (364 * globalAnalysis.sustainabilityScorecard.score / 100) }}
                              className="text-emerald-500"
                            />
                          </svg>
                          <div className="absolute inset-0 flex flex-col items-center justify-center">
                            <span className="text-3xl font-black">{globalAnalysis.sustainabilityScorecard.score}</span>
                            <span className="text-[10px] uppercase font-bold text-zinc-500">Score</span>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <p className="text-xs font-bold text-emerald-400 uppercase tracking-widest text-center mb-4">Grade: {globalAnalysis.sustainabilityScorecard.grade}</p>
                        {globalAnalysis.sustainabilityScorecard.metrics.map((m, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs text-zinc-400">
                            <div className="w-1 h-1 bg-emerald-500 rounded-full mt-1.5 shrink-0" />
                            {m}
                          </div>
                        ))}
                      </div>
                    </section>

                    <section className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden">
                      <div className="bg-rose-600 px-6 py-4 flex items-center gap-3">
                        <Zap className="text-white w-5 h-5" />
                        <h2 className="text-white font-bold">Anomaly Detection</h2>
                      </div>
                      <div className="p-6 space-y-6">
                        {globalAnalysis.anomalyReport.map((report, i) => (
                          <div key={i} className="space-y-3">
                            <div className="flex items-center gap-2">
                              <AlertTriangle className="w-4 h-4 text-rose-500" />
                              <h3 className="text-sm font-bold text-zinc-900">{report.zoneId} Finding</h3>
                            </div>
                            <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl">
                              <p className="text-xs text-rose-700 font-medium">{report.finding}</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-[10px] font-black text-zinc-400 uppercase">Immediate Intervention</p>
                              <p className="text-xs text-emerald-700 font-bold bg-emerald-50 p-3 rounded-xl border border-emerald-100">{report.intervention}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </section>
                  </div>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div 
              key="zone-view"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8"
            >
              {/* Left Column: Metrics & Charts */}
              <div className="lg:col-span-8 space-y-8">
                {/* Anomaly Banner */}
                <AnimatePresence>
                  {data.anomaly && (
                    <motion.div 
                      initial={{ opacity: 0, y: -20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="bg-rose-50 border border-rose-200 rounded-2xl p-4 flex items-center gap-4"
                    >
                      <div className="w-10 h-10 bg-rose-500 rounded-xl flex items-center justify-center shrink-0">
                        <AlertTriangle className="text-white w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-rose-900">Critical Anomaly Detected</h3>
                        <p className="text-xs text-rose-700 font-medium">{data.anomaly}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Quick Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <StatCard title="Soil Moisture" value={data.soil.moisture} unit="%" icon={Droplets} color="bg-blue-500" />
                  <StatCard title="NDVI Index" value={data.satellite.ndvi} unit="" icon={Leaf} color="bg-emerald-500" />
                  <StatCard title="Soil Temp" value={data.soil.temperature} unit="°C" icon={Thermometer} color="bg-orange-500" />
                  <StatCard title="Nitrogen" value={data.soil.nitrogen} unit="mg/kg" icon={Activity} color="bg-indigo-500" />
                </div>

                {/* Main Visualization Area */}
                <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden">
                  <div className="border-b border-zinc-100 px-6 py-4 flex items-center justify-between">
                    <div className="flex gap-4">
                      {['overview', 'soil', 'satellite', 'weather'].map((tab) => (
                        <button
                          key={tab}
                          onClick={() => setActiveTab(tab as any)}
                          className={cn(
                            "text-sm font-semibold pb-4 -mb-4 transition-colors relative",
                            activeTab === tab ? "text-emerald-600" : "text-zinc-400 hover:text-zinc-600"
                          )}
                        >
                          {tab.charAt(0).toUpperCase() + tab.slice(1)}
                          {activeTab === tab && (
                            <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-600" />
                          )}
                        </button>
                      ))}
                    </div>
                    <div className="flex items-center gap-2 text-xs font-medium text-zinc-400">
                      <Layers className="w-4 h-4" />
                      {data.cropType} • {data.location}
                    </div>
                  </div>

                  <div className="p-6 h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      {activeTab === 'weather' ? (
                        <AreaChart data={data.weather}>
                          <defs>
                            <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#f97316" stopOpacity={0.1}/>
                              <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorPrecip" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f1" />
                          <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8'}} />
                          <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8'}} />
                          <Tooltip 
                            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                          />
                          <Area type="monotone" dataKey="tempMax" stroke="#f97316" fillOpacity={1} fill="url(#colorTemp)" strokeWidth={2} name="Max Temp" />
                          <Area type="monotone" dataKey="precipitation" stroke="#3b82f6" fillOpacity={1} fill="url(#colorPrecip)" strokeWidth={2} name="Precipitation" />
                        </AreaChart>
                      ) : activeTab === 'soil' ? (
                        <BarChart data={[
                          { name: 'Nitrogen', value: data.soil.nitrogen },
                          { name: 'Phosphorus', value: data.soil.phosphorus },
                          { name: 'Potassium', value: data.soil.potassium / 3 }, // Scaled for visualization
                          { name: 'Moisture', value: data.soil.moisture },
                        ]}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f1" />
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#94a3b8'}} />
                          <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#94a3b8'}} />
                          <Tooltip cursor={{fill: '#f8fafc'}} />
                          <Bar dataKey="value" radius={[4, 4, 0, 0]} barSize={40}>
                            { [0,1,2,3].map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={['#6366f1', '#ec4899', '#f59e0b', '#3b82f6'][index]} />
                            ))}
                          </Bar>
                        </BarChart>
                      ) : (
                        <LineChart data={data.weather.map((w, i) => ({ ...w, ndvi: data.satellite.ndvi + (Math.sin(i) * 0.05) }))}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f1" />
                          <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8'}} />
                          <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8'}} />
                          <Tooltip />
                          <Line type="monotone" dataKey="ndvi" stroke="#10b981" strokeWidth={3} dot={{ r: 4, fill: '#10b981' }} activeDot={{ r: 6 }} />
                        </LineChart>
                      )}
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Optimization Goals Balance */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white p-6 rounded-2xl border border-zinc-200 shadow-sm">
                    <div className="flex items-center gap-2 mb-4">
                      <Sprout className="w-5 h-5 text-emerald-600" />
                      <h4 className="text-sm font-bold uppercase tracking-wider text-zinc-500">Yield Projection</h4>
                    </div>
                    <div className="relative pt-1">
                      <div className="flex mb-2 items-center justify-between">
                        <div>
                          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-emerald-600 bg-emerald-200">
                            {insights?.yieldProjection && insights.yieldProjection > 80 ? 'Optimal' : 'Sub-optimal'}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold inline-block text-emerald-600">
                            {insights?.yieldProjection || 0}%
                          </span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-emerald-100">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${insights?.yieldProjection || 0}%` }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-emerald-500"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-2xl border border-zinc-200 shadow-sm">
                    <div className="flex items-center gap-2 mb-4">
                      <Droplets className="w-5 h-5 text-blue-600" />
                      <h4 className="text-sm font-bold uppercase tracking-wider text-zinc-500">Water Efficiency</h4>
                    </div>
                    <div className="relative pt-1">
                      <div className="flex mb-2 items-center justify-between">
                        <div>
                          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200">
                            {insights?.waterEfficiency && insights.waterEfficiency > 70 ? 'High' : 'Moderate'}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold inline-block text-blue-600">
                            {insights?.waterEfficiency || 0}%
                          </span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-100">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${insights?.waterEfficiency || 0}%` }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-2xl border border-zinc-200 shadow-sm">
                    <div className="flex items-center gap-2 mb-4">
                      <Leaf className="w-5 h-5 text-indigo-600" />
                      <h4 className="text-sm font-bold uppercase tracking-wider text-zinc-500">Sustainability</h4>
                    </div>
                    <div className="relative pt-1">
                      <div className="flex mb-2 items-center justify-between">
                        <div>
                          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-indigo-600 bg-indigo-200">
                            {insights?.sustainabilityScore && insights.sustainabilityScore > 75 ? 'Excellent' : 'Good'}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold inline-block text-indigo-600">
                            {insights?.sustainabilityScore || 0}%
                          </span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-indigo-100">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${insights?.sustainabilityScore || 0}%` }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-indigo-500"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column: AI Engine Insights */}
              <div className="lg:col-span-4 space-y-6">
                <div className="bg-zinc-900 text-white rounded-2xl p-6 shadow-xl border border-zinc-800">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
                      <Activity className="w-5 h-5 text-zinc-900" />
                    </div>
                    <h2 className="text-lg font-bold">AI Reasoning Engine</h2>
                  </div>

                  <AnimatePresence mode="wait">
                    {loading ? (
                      <motion.div 
                        key="loading"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="space-y-4 py-8 text-center"
                      >
                        <div className="inline-block w-12 h-12 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin mb-4" />
                        <p className="text-zinc-400 text-sm font-medium">Analyzing Zone {selectedZoneId} environmental dynamics...</p>
                      </motion.div>
                    ) : insights ? (
                      <motion.div 
                        key="content"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                      >
                        <div className="bg-zinc-800/50 rounded-xl p-4 border border-zinc-700">
                          <p className="text-sm text-zinc-300 leading-relaxed italic">
                            "{insights.summary}"
                          </p>
                        </div>

                        <div className="space-y-4">
                          <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-500">Actionable Insights</h3>
                          {insights.recommendations.map((rec, i) => (
                            <div key={i} className="group relative bg-zinc-800/30 hover:bg-zinc-800/50 transition-colors p-4 rounded-xl border border-zinc-700/50">
                              <div className="flex justify-between items-start mb-2">
                                <span className={cn(
                                  "text-[10px] font-bold uppercase px-2 py-0.5 rounded-full",
                                  rec.priority === 'High' ? "bg-rose-500/20 text-rose-400" : 
                                  rec.priority === 'Medium' ? "bg-amber-500/20 text-amber-400" : 
                                  "bg-blue-500/20 text-blue-400"
                                )}>
                                  {rec.priority} Priority
                                </span>
                                <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-emerald-500 transition-colors" />
                              </div>
                              <h4 className="text-sm font-bold text-white mb-1">{rec.action}</h4>
                              <p className="text-xs text-zinc-400 leading-snug">{rec.impact}</p>
                            </div>
                          ))}
                        </div>

                        <div className="pt-4 border-t border-zinc-800">
                          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                            <CheckCircle2 className="w-4 h-4" />
                            Multi-Objective Optimization Complete
                          </div>
                        </div>
                      </motion.div>
                    ) : (
                      <div className="text-center py-12">
                        <AlertTriangle className="w-12 h-12 text-zinc-700 mx-auto mb-4" />
                        <p className="text-zinc-500 text-sm">No optimization data available.</p>
                      </div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Environmental Context */}
                <div className="bg-white rounded-2xl p-6 border border-zinc-200 shadow-sm">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-zinc-500 mb-4">7-Day Forecast</h3>
                  <div className="space-y-4">
                    {data.weather.map((day, i) => (
                      <div key={i} className="flex items-center justify-between py-2 border-b border-zinc-50 last:border-0">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-zinc-100 rounded-lg flex items-center justify-center">
                            {day.precipitation > 5 ? <CloudRain className="w-4 h-4 text-blue-500" /> : <Wind className="w-4 h-4 text-zinc-400" />}
                          </div>
                          <div>
                            <p className="text-xs font-bold text-zinc-700">{new Date(day.date).toLocaleDateString('en-US', { weekday: 'short' })}</p>
                            <p className="text-[10px] text-zinc-400">{day.precipitation.toFixed(1)}mm rain</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-bold text-zinc-900">{day.tempMax.toFixed(0)}°</p>
                          <p className="text-[10px] text-zinc-400">{day.tempMin.toFixed(0)}°</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-8 border-t border-zinc-200 mt-12">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2 grayscale opacity-50">
            <Sprout className="w-5 h-5" />
            <span className="text-sm font-bold tracking-tight">TerraEdge AI</span>
          </div>
          <p className="text-xs text-zinc-400">© 2026 Climate-Resilient Precision Agriculture Systems. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="text-xs font-semibold text-zinc-400 hover:text-emerald-600 transition-colors">System Status</a>
            <a href="#" className="text-xs font-semibold text-zinc-400 hover:text-emerald-600 transition-colors">API Docs</a>
            <a href="#" className="text-xs font-semibold text-zinc-400 hover:text-emerald-600 transition-colors">Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
