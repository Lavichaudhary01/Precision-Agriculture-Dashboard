import folium
from folium.plugins import HeatMap
import matplotlib.pyplot as plt
import json
import io
import base64
from datetime import datetime

# --- EDGE DEPLOYMENT NOTES ---
# To deploy on an edge device (e.g., Raspberry Pi) with low-bandwidth constraints:
# 1. Use Flask or FastAPI to serve this as a lightweight API.
# 2. Instead of sending raw high-res imagery, send only the generated HTML map 
#    or compressed base64 plot strings to the client.
# 3. Implement local caching of sensor data to minimize external API calls.
# 4. Use 'gunicorn' or 'uvicorn' as a production server on the Pi.
# 5. Example Flask Route:
#    @app.route('/map')
#    def get_map():
#        return generate_farm_map()._repr_html_()
# -----------------------------

def generate_farm_data():
    """Simulated data for 4 farm zones based on the TerraEdge system."""
    return [
        {"id": "Zone 1", "lat": 36.51, "lon": -120.51, "ndvi": 0.72, "moisture": 35},
        {"id": "Zone 2", "lat": 36.51, "lon": -120.49, "ndvi": 0.65, "moisture": 42},
        {"id": "Zone 3", "lat": 36.49, "lon": -120.51, "ndvi": 0.42, "moisture": 28}, # Anomaly Zone
        {"id": "Zone 4", "lat": 36.49, "lon": -120.49, "ndvi": 0.78, "moisture": 38},
    ]

def create_geospatial_heatmap(zones):
    """Generates a Folium map with a heatmap layer for NDVI."""
    # Center map on the farm location
    farm_map = folium.Map(location=[36.50, -120.50], zoom_start=14, tiles='OpenStreetMap')
    
    # Prepare data for HeatMap: [lat, lon, intensity]
    # We use NDVI as the intensity for the heatmap
    heat_data = [[z['lat'], z['lon'], z['ndvi']] for z in zones]
    
    # Add HeatMap layer
    HeatMap(heat_data, radius=50, blur=30, min_opacity=0.5).add_to(farm_map)
    
    # Add markers for each zone with popup info
    for z in zones:
        color = 'green' if z['ndvi'] > 0.6 else 'orange' if z['ndvi'] > 0.5 else 'red'
        folium.Marker(
            location=[z['lat'], z['lon']],
            popup=f"<b>{z['id']}</b><br>NDVI: {z['ndvi']}<br>Moisture: {z['moisture']}%",
            icon=folium.Icon(color=color, icon='leaf')
        ).add_to(farm_map)
        
    return farm_map

def create_metrics_plot(zones):
    """Generates a Matplotlib bar chart comparing NDVI and Moisture."""
    ids = [z['id'] for z in zones]
    ndvi_vals = [z['ndvi'] for z in zones]
    moisture_vals = [z['moisture'] / 100.0 for z in zones] # Scale moisture for comparison

    fig, ax = plt.subplots(figsize=(8, 4))
    width = 0.35
    x = range(len(ids))

    ax.bar([i - width/2 for i in x], ndvi_vals, width, label='NDVI', color='#10b981')
    ax.bar([i + width/2 for i in x], moisture_vals, width, label='Moisture (Scaled)', color='#3b82f6')

    ax.set_ylabel('Index / Scaled Value')
    ax.set_title('Zone Health Comparison')
    ax.set_xticks(x)
    ax.set_xticklabels(ids)
    ax.legend()
    
    plt.tight_layout()
    
    # Save to a buffer to simulate API response
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    return base64.b64encode(buf.read()).decode('utf-8')

if __name__ == "__main__":
    print(f"--- TerraEdge AI Edge PoC Engine ---")
    print(f"Timestamp: {datetime.now().isoformat()}")
    
    # 1. Generate Data
    farm_zones = generate_farm_data()
    print(f"Data generated for {len(farm_zones)} zones.")
    
    # 2. Create Heatmap
    m = create_geospatial_heatmap(farm_zones)
    m.save("farm_heatmap.html")
    print("Geospatial heatmap saved to 'farm_heatmap.html'")
    
    # 3. Create Metrics Plot
    plot_b64 = create_metrics_plot(farm_zones)
    print("Metrics plot generated as base64 string.")
    
    print("\n[SUCCESS] PoC components generated.")
    print("To run as an API, wrap these functions in a Flask/FastAPI app.")
